Demo images under
Creative Commons Attribution License:
http://www.flickr.com/photos/geishaboy500/
